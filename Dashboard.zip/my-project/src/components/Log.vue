<template>
    <div class="mt-4 border border-gray-200 rounded shadow p-4">
        <h1 class="text-2xl font-bold mb-4">Log</h1>
        <div v-if="loading" class="text-blue-500">Loading...</div>
        <div v-if="error" class="text-red-500">{{ error }}</div>
        <div v-if="data" class="space-y-2">
            <n-pagination v-model:page="page" :page-count="Math.ceil(data.length / pageSize)" />
            <div v-for="(item, index) in data.slice((page - 1) * pageSize, page * pageSize)" :key="index" class="p-2 bg-gray-100 rounded shadow">
                <VueJsonView :src="parseResponseBodyInResponseData(item)" :sortKeys=true theme="summerfruit:inverted" :collapsed=2 />
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { NPagination } from 'naive-ui';
import VueJsonView from '@matpool/vue-json-view'

const data = ref(null);
const loading = ref(true);
const error = ref(null);
const page = ref(1);
const pageSize = 5;

const fetchData = async () => {
    try {
        const response = await fetch('http://localhost:8080/log?collectionName=Log');
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const responseData = await response.json();
        data.value = responseData;
    } catch (err) {
        error.value = `Failed to fetch data: ${err.message}`;
    } finally {
        loading.value = false;
    }
};

const parseResponseBodyInResponseData = (item) => {
    if (item.response_body && typeof item.response_body === 'string') {
        item.response_body = JSON.parse(item.response_body);
    }
    if (item.response_message && typeof item.response_message === 'string') {
        item.response_message = JSON.parse(item.response_message);
    }
    return item;
};

onMounted(() => {
    fetchData();
});
</script>

<style scoped>
/* Add any custom styles if necessary */
</style>