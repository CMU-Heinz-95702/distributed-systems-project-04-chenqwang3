<template>
    <div class="mt-4 border border-gray-200 rounded shadow p-4">
        <div v-if="loading" class="text-blue-500">Loading...</div>
        <div v-if="error" class="text-red-500">{{ error }}</div>
        <div v-if="data" class="space-y-2">
            {{ data }}
        </div>
        <v-chart class="chart" :option="option" autoresize />
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { use } from 'echarts/core';
import { CanvasRenderer } from 'echarts/renderers';
import { PieChart } from 'echarts/charts';
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
} from 'echarts/components';
import VChart from 'vue-echarts';

const data = ref(null);
const loading = ref(true);
const error = ref(null);
const option = ref({});

const fetchData = async () => {
    try {
        const response = await fetch('http://localhost:8080/log?collectionName=QueryLog');
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const responseData = await response.json();
        const terms = responseData.map((item) => item.queryTerm);
        const occurrences = responseData.map((item) => item.occurrence);
        option.value = {
            title: {
                text: 'Icon search terms',
                left: 'center',
            },
            tooltip: {
                trigger: 'item',
                formatter: '{a} <br/>{b} : {c} ({d}%)',
            },
            legend: {
                orient: 'vertical',
                left: 'left',
                data: terms,
            },
            series: [
                {
                    name: 'Search terms',
                    type: 'pie',
                    radius: '55%',
                    center: ['50%', '60%'],
                    data: terms.map((term, index) => ({
                        value: occurrences[index],
                        name: term,
                    })),
                    emphasis: {
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)',
                        },
                    },
                },
            ],
        };
    } catch (err) {
        error.value = `Failed to fetch data: ${err.message}`;
    } finally {
        loading.value = false;
    }
};

onMounted(() => {
    fetchData();
});

use([
  CanvasRenderer,
  PieChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
]);
</script>

<style scoped>
.chart {
  height: 400px;
}
</style>