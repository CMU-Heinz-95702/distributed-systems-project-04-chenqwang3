<template>
    <div class="mt-4 border border-gray-200 rounded shadow p-4">
        <div v-if="loading" class="text-blue-500">Loading...</div>
        <div v-if="error" class="text-red-500">{{ error }}</div>
        <div v-if="data" class="space-y-2">
            {{ data }}
        </div>
        <v-chart class="chart" :option="option" autoresize />
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { use } from 'echarts/core';
import { CanvasRenderer } from 'echarts/renderers';
import { LineChart } from 'echarts/charts';
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
} from 'echarts/components';
import VChart from 'vue-echarts';

const data = ref(null);
const loading = ref(true);
const error = ref(null);
const option = ref({});

const fetchData = async () => {
    try {
        const response = await fetch('http://localhost:8080/log?collectionName=LatencyLog');
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const responseData = await response.json();
        const latency = responseData.map((item) => item.latency);
        let i = 0;
        const id  = latency.map(() => i++);
        option.value = {
            title: {
                text: 'Response Latency',
                left: 'center',
            },
            tooltip: {
                trigger: 'axis',
            },
            legend: {
                data: ['Latency'],
                left: 'left',
            },
            xAxis: {
                type: 'category',
                data: id,
            },
            yAxis: {
                type: 'value',
                name: 'Latency (ms)',
            },
            series: [
                {
                    name: 'Latency',
                    type: 'line',
                    data: latency,
                },
            ],
        };
    } catch (err) {
        error.value = `Failed to fetch data: ${err.message}`;
    } finally {
        loading.value = false;
    }
};

onMounted(() => {
    fetchData();
});

use([
  CanvasRenderer,
  LineChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
]);
</script>

<style scoped>
.chart {
  height: 400px;
}
</style>