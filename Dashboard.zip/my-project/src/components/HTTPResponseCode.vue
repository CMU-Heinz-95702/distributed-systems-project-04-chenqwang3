<template>
    <div class="mt-4 border border-gray-200 rounded shadow p-4">
        <div v-if="loading" class="text-blue-500">Loading...</div>
        <div v-if="error" class="text-red-500">{{ error }}</div>
        <div v-if="data" class="space-y-2">
            {{ data }}
        </div>
        <v-chart class="chart" :option="option" autoresize />
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { use } from 'echarts/core';
import { CanvasRenderer } from 'echarts/renderers';
import { BarChart } from 'echarts/charts';
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
} from 'echarts/components';
import VChart from 'vue-echarts';

const data = ref(null);
const loading = ref(true);
const error = ref(null);
const option = ref({});

const fetchData = async () => {
    try {
        const response = await fetch('http://localhost:8080/log?collectionName=HTTPResponseCodeLog');
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const responseData = await response.json();
        responseData.sort((a, b) => a.responseCode - b.responseCode);
        const responseCodes = responseData.map((item) => item.responseCode);
        const occurrences = responseData.map((item) => item.occurrence);
        option.value = {
            title: {
                text: 'HTTP response codes',
                left: 'center',
            },
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow',
                },
            },
            legend: {
                data: ['Occurrences'],
                left: 'left',
            },
            xAxis: {
                type: 'category',
                data: responseCodes,
            },
            yAxis: {
                type: 'value',
            },
            series: [
                {
                    name: 'Occurrences',
                    type: 'bar',
                    data: occurrences,
                },
            ],
        };
    } catch (err) {
        error.value = `Failed to fetch data: ${err.message}`;
    } finally {
        loading.value = false;
    }
};

onMounted(() => {
    fetchData();
});

use([
  CanvasRenderer,
  BarChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
]);
</script>

<style scoped>
.chart {
  height: 400px;
}
</style>