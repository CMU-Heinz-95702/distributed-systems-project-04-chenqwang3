<script setup>
import Header from './components/Header.vue';
import Log from './components/Log.vue';
import QueryTerm from './components/QueryTerm.vue';
import HTTPResponseCode from './components/HTTPResponseCode.vue';
import Latency from './components/Latency.vue';
</script>

<template>
  <Header />
  <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-extrabold text-gray-900">Icon Finder Dashboard</h1>
    <div class="grid grid-cols-1 gap-4 md:grid-cols-2 mt-4">
      <QueryTerm />
      <Latency />
      <HTTPResponseCode />
    </div>
    <Log />
  </main>
</template>